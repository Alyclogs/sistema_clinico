<?php
require_once __DIR__ . '/../../config/database.php';

class CitasModel
{
    private $db;
    public function __construct()
    {
        $this->db = connectDatabase();
    }

    public function obtenerCitasPorEspecialista($idespecialista)
    {
       $sql = "SELECT 
                c.*, 
                p.nombres AS paciente_nombres, 
                p.apellidos AS paciente_apellidos, 
                p.dni AS paciente_dni, 
                p.fecha_nacimiento AS paciente_fecha_nacimiento
            FROM citas c
            INNER JOIN pacientes p ON c.idpaciente = p.idpaciente
            WHERE c.idespecialista = :idespecialista";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':idespecialista', $idespecialista, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}